
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PC
 */
public class ProcessStudent {
    public void sortStudent(List<Student> l){
        //TODO: you should do sort list l here
       
    }
    public List<Student> find_by_partial_name(List<Student> l,String letter){
        ArrayList<Student> filteredL = new ArrayList();
        //TODO: you should return filtered List of student by name here
       
        return filteredL;
    }
    public List<Student> find_higher_gpa(List<Student> l,int gpa){
        ArrayList<Student> filteredL = new ArrayList();
        //TODO: you should filter whose gpa are higher than given gpa here
       
        return filteredL;
    }
}
